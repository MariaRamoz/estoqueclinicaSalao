@echo off
title Clinica Lyara Rodrigues - Estoque

:: Garante que o script executa na pasta correta, mesmo se aberto como administrador ou via atalho
cd /d "%~dp0"

echo.
echo ==========================================================
echo        Iniciando o sistema de estoque - Clinica Lyara
echo ==========================================================
echo.

:: Verifica se o Node.js esta instalado e acessivel
node -v >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERRO] O Node.js nao foi encontrado no seu computador!
    echo.
    echo Para rodar o sistema localmente, voce precisa ter o Node.js instalado.
    echo Por favor, baixe e instale a versao recomendada ^(LTS^) em:
    echo https://nodejs.org/
    echo.
    echo Apos a instalacao, feche e abra este arquivo novamente.
    echo.
    echo Pressione qualquer tecla para fechar esta janela...
    pause >nul
    exit /b 1
)

:: Abre o navegador padrao no endereco local
start "" "http://localhost:3000"

:: Inicia o servidor local
node server.js

:: Se o node falhar ao rodar (ex: porta 3000 ja ocupada), mantem a janela aberta para ler o erro
if %errorlevel% neq 0 (
    echo.
    echo [ERRO] Nao foi possivel manter o servidor ativo.
    echo Verifique se outra janela do estoque ja esta aberta ou se o terminal apresentou erros.
    echo.
    pause
)

