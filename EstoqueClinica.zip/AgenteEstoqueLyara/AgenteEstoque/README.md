# 🌸 Clínica Lyara Rodrigues – Gestão de Estoque

Sistema moderno, premium e responsivo para controle e gestão de estoque da **Clínica Lyara Rodrigues**. O sistema integra-se de forma instantânea com o **Google Sheets**, servindo como banco de dados em tempo real por meio do Google Apps Script.

---

## 🚀 Funcionalidades Principais

*   **Visão Geral (Dashboard):** KPIs em tempo real contendo total de itens, contagem de estoque baixo, valor total investido em estoque, profissionais ativos e painel de movimentações recentes em ordem cronológica.
*   **Cadastro & Gestão:**
    *   **Produtos:** Controle de quantidade atual, estoque mínimo, custo unitário, validade, fornecedores e observações.
    *   **Entradas:** Registro de novas unidades adicionadas, custo, data, fornecedor e profissional responsável.
    *   **Saídas:** Registro de consumo de materiais, data, profissional solicitante, motivo e observações adicionais.
    *   **Profissionais & Fornecedores:** Cadastros auxiliares integrados para vinculação rápida às movimentações.
*   **Sincronização Instantânea em Segundo Plano:** O sistema salva as alterações localmente (`localStorage`) de forma imediata e faz a sincronização assíncrona com a planilha na nuvem sem bloquear a tela do usuário.
*   **Relatórios Integrados:** Geração e exportação/impressão de relatórios de Estoque Atual, Entradas, Saídas e Consumo por Profissional.
*   **Interface Premium:** Design elegante, responsivo e adaptado para celulares com a paleta de cores oficial da clínica.

---

## 🛠️ Arquitetura do Projeto

*   **Front-end:** HTML5 (estrutura semântica), Vanilla CSS3 (variáveis, flexbox, grid e animações) e Vanilla JavaScript (manipulação de DOM, requisições HTTP e gerenciamento de fila de sincronização).
*   **Banco de Dados:** Google Sheets.
*   **Back-end/API:** Google Apps Script (`Code.gs`) implantado como Web App.

---

## 📋 Como Configurar e Sincronizar com a Planilha (Uma única vez)

1.  Acesse o [Google Apps Script](https://script.google.com).
2.  Crie um **Novo Projeto**.
3.  Copie o conteúdo de [Code.gs](file:///c:/Agente1teste/AgenteEstoqueLyara/AgenteEstoque/Code.gs) e cole dentro do editor de código do projeto. Salve as alterações.
4.  No menu superior, selecione a função **`setupSpreadsheet`** e clique em **Executar** (Autorize as permissões necessárias na primeira execução). Isto criará todas as abas necessárias na sua planilha.
5.  Clique no botão azul **Implantar** (Deploy) no canto superior direito → **Nova implantação** (New deployment).
    *   **Tipo de implantação:** *App da Web* (Web App).
    *   **Executar como:** *Eu (sua conta de e-mail)*.
    *   **Quem pode acessar:** *Qualquer pessoa* (Anyone).
6.  Clique em **Implantar** e copie a **URL do App da Web** gerada (ex: `https://script.google.com/macros/s/.../exec`).
7.  Abra o aplicativo, clique no botão ⚙️ **Sheets** no canto superior direito, cole a URL copiada no campo indicado e clique em **Salvar e Sincronizar**.

---

## 🖥️ Como Executar Localmente

Caso queira rodar o servidor estático localmente no computador da clínica:

1.  Certifique-se de ter o [Node.js](https://nodejs.org) instalado.
2.  Dê dois cliques no arquivo [iniciar.bat](file:///c:/Agente1teste/AgenteEstoqueLyara/AgenteEstoque/iniciar.bat) localizado na pasta raiz do projeto.
3.  O terminal iniciará o servidor e abrirá automaticamente o aplicativo no endereço: `http://localhost:3000`.

---

## ☁️ Como Publicar na Web (Vercel)

Para hospedar o site na nuvem gratuitamente e com segurança:

1.  Crie um **repositório privado** no seu [GitHub](https://github.com) e envie os arquivos do projeto para lá.
2.  Acesse a [Vercel](https://vercel.com) e crie uma conta usando o seu login do GitHub.
3.  No painel da Vercel, clique em **Add New → Project**, selecione o repositório privado `clinica-lyara-estoque` e clique em **Import**.
4.  Clique em **Deploy**.
5.  Em segundos o site estará online em um link seguro e otimizado (ex: `lyara-estoque.vercel.app`).

---

## 🔒 Segurança dos Dados

Como este repositório armazena a URL de acesso à planilha do cliente, siga uma destas boas práticas de segurança:
*   Mantenha o repositório do **GitHub privado** ao integrar com a Vercel.
*   Alternativamente, remova a URL padrão definindo `const DEFAULT_SHEETS_URL = '';` no arquivo `app.js`. Dessa forma, a URL da planilha será configurada manualmente por meio do navegador do cliente e armazenada apenas de forma local e segura (`localStorage`).
