// =====================================================
// CLÍNICA LYARA RODRIGUES – Google Apps Script
// =====================================================
// COMO CONFIGURAR (faça isso UMA VEZ):
//
//  1. Acesse: https://script.google.com
//  2. Crie um novo projeto → cole TODO este código
//  3. No menu, clique em "Executar" → "setupSpreadsheet"
//     (Autorize as permissões quando solicitado)
//  4. Vá em "Implantar" → "Novo implantação"
//     - Tipo: App da Web
//     - Executar como: EU (minha conta)
//     - Quem pode acessar: QUALQUER PESSOA
//  5. Clique em "Implantar" e copie a URL gerada
//  6. No app, clique em ⚙ Configurar e cole a URL
// =====================================================

const SS_ID = '1lWWnjtHqkID-TXp87_3_DEQIw4xcaZnNNAHAaV3Rooc';

// Função auxiliar para obter a planilha ativa (vinculada) ou abrir pelo ID (standalone)
function getSS() {
  try {
    return SpreadsheetApp.getActiveSpreadsheet() || SpreadsheetApp.openById(SS_ID);
  } catch (e) {
    return SpreadsheetApp.openById(SS_ID);
  }
}

const SHEET_NAMES = {
  profissionais: 'Profissionais',
  produtos:      'Produtos',
  entradas:      'Entradas',
  saidas:        'Saídas',
  fornecedores:  'Fornecedores',
  mestra:        'Mestra',
};

const HEADERS = {
  profissionais: ['id','nome','especialidade','registro','telefone','email','status'],
  produtos:      ['id','nome','categoria','unidade','quantidade','minimo','custo','validade','fornecedor','fornecedorNome','obs'],
  entradas:      ['id','produto','produtoNome','quantidade','custo','data','fornecedor','fornecedorNome','profissional','profissionalNome','obs'],
  saidas:        ['id','produto','produtoNome','quantidade','data','profissional','profissionalNome','motivo','obs'],
  fornecedores:  ['id','nome','contato','telefone','email','produtos'],
};

const COR_ROSA   = '#C4879A';
const COR_MEDIA  = '#D9B0B7';
const COR_BRANCO = '#FFFFFF';
const COR_OFFWH  = '#F2F2F2';

// ============= doGet (Leitura) =============
function doGet(e) {
  try {
    const ss     = getSS();
    const action = (e && e.parameter && e.parameter.action) ? e.parameter.action : 'getData';

    if (action === 'getData') {
      const result = {};
      Object.keys(HEADERS).forEach(key => {
        result[key] = readSheet(ss, SHEET_NAMES[key], HEADERS[key]);
      });
      result.mestra = calcularMestra(result.produtos, result.entradas, result.saidas);
      return makeResponse(result);
    }

    if (action === 'setup') {
      setupSpreadsheet();
      return makeResponse({ success: true, message: 'Planilha configurada com sucesso!' });
    }

    return makeResponse({ error: 'Ação desconhecida: ' + action });

  } catch (err) {
    Logger.log('doGet error: ' + err.toString());
    return makeResponse({ error: err.message || err.toString() });
  }
}

// ============= doPost (Escrita) =============
function doPost(e) {
  try {
    const ss   = getSS();
    const body = JSON.parse(e.postData.contents);
    const { action, entity, data, state } = body;

    if (action === 'save' && entity) {
      const sheetName = SHEET_NAMES[entity];
      if (!sheetName) return makeResponse({ error: 'Entidade inválida: ' + entity });
      writeSheet(ss, sheetName, HEADERS[entity], data || []);

      if (['produtos','entradas','saidas'].includes(entity) && state) {
        const mestra = calcularMestra(
          state.produtos || [],
          state.entradas || [],
          state.saidas   || []
        );
        try { writeMestra(ss, mestra); } catch(e) {}
      }
      return makeResponse({ success: true, entity });
    }

    if (action === 'saveAll' && state) {
      Object.keys(HEADERS).forEach(key => {
        if (Array.isArray(state[key])) {
          writeSheet(ss, SHEET_NAMES[key], HEADERS[key], state[key]);
        }
      });
      try { writeMestra(ss, calcularMestra(state.produtos||[], state.entradas||[], state.saidas||[])); } catch(e) {}
      return makeResponse({ success: true });
    }

    return makeResponse({ error: 'Ação desconhecida' });

  } catch (err) {
    Logger.log('doPost error: ' + err.toString());
    return makeResponse({ error: err.message || err.toString() });
  }
}

// ============= HELPERS =============
function makeResponse(data) {
  return ContentService
    .createTextOutput(JSON.stringify(data))
    .setMimeType(ContentService.MimeType.JSON);
}

function readSheet(ss, sheetName, headers) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet && sheetName === 'Saídas') {
    sheet = ss.getSheetByName('Saidas') || ss.getSheetByName('Saída') || ss.getSheetByName('Saida');
    if (sheet) { try { sheet.setName('Saídas'); } catch(e) {} }
  }
  if (!sheet && sheetName === 'Produtos') {
    sheet = ss.getSheetByName('Produto') || ss.getSheetByName('produtos') || ss.getSheetByName('produto');
    if (sheet) { try { sheet.setName('Produtos'); } catch(e) {} }
  }
  if (!sheet && sheetName === 'Entradas') {
    sheet = ss.getSheetByName('Entrada') || ss.getSheetByName('entradas') || ss.getSheetByName('entrada');
    if (sheet) { try { sheet.setName('Entradas'); } catch(e) {} }
  }
  if (!sheet && sheetName === 'Profissionais') {
    sheet = ss.getSheetByName('Profissional') || ss.getSheetByName('profissionais') || ss.getSheetByName('profissional');
    if (sheet) { try { sheet.setName('Profissionais'); } catch(e) {} }
  }
  if (!sheet && sheetName === 'Fornecedores') {
    sheet = ss.getSheetByName('Fornecedor') || ss.getSheetByName('fornecedores') || ss.getSheetByName('fornecedor');
    if (sheet) { try { sheet.setName('Fornecedores'); } catch(e) {} }
  }
  if (!sheet) return [];
  const lastRow = sheet.getLastRow();
  if (lastRow < 2) return [];

  const values = sheet.getRange(2, 1, lastRow - 1, headers.length).getValues();
  return values
    .filter(row => row[0] !== '' && row[0] !== null && row[0] !== undefined)
    .map(row => {
      const obj = {};
      headers.forEach((h, i) => {
        let val = row[i];
        if (val instanceof Date) {
          val = Utilities.formatDate(val, Session.getScriptTimeZone(), 'yyyy-MM-dd');
        } else if (val === null || val === undefined) {
          val = '';
        }
        obj[h] = val;
      });
      return obj;
    });
}

function writeSheet(ss, sheetName, headers, data) {
  let sheet = ss.getSheetByName(sheetName);
  if (!sheet && sheetName === 'Saídas') {
    sheet = ss.getSheetByName('Saidas') || ss.getSheetByName('Saída') || ss.getSheetByName('Saida');
    if (sheet) { try { sheet.setName('Saídas'); } catch(e) {} }
  }
  if (!sheet && sheetName === 'Produtos') {
    sheet = ss.getSheetByName('Produto') || ss.getSheetByName('produtos') || ss.getSheetByName('produto');
    if (sheet) { try { sheet.setName('Produtos'); } catch(e) {} }
  }
  if (!sheet && sheetName === 'Entradas') {
    sheet = ss.getSheetByName('Entrada') || ss.getSheetByName('entradas') || ss.getSheetByName('entrada');
    if (sheet) { try { sheet.setName('Entradas'); } catch(e) {} }
  }
  if (!sheet && sheetName === 'Profissionais') {
    sheet = ss.getSheetByName('Profissional') || ss.getSheetByName('profissionais') || ss.getSheetByName('profissional');
    if (sheet) { try { sheet.setName('Profissionais'); } catch(e) {} }
  }
  if (!sheet && sheetName === 'Fornecedores') {
    sheet = ss.getSheetByName('Fornecedor') || ss.getSheetByName('fornecedores') || ss.getSheetByName('fornecedor');
    if (sheet) { try { sheet.setName('Fornecedores'); } catch(e) {} }
  }
  if (!sheet) sheet = ss.insertSheet(sheetName);

  sheet.clearContents();
  try { sheet.clearFormats(); } catch(e) {}

  const headerLabels = {
    id:'ID', nome:'NOME', especialidade:'ESPECIALIDADE', registro:'REGISTRO',
    telefone:'TELEFONE', email:'E-MAIL', status:'STATUS', categoria:'CATEGORIA',
    unidade:'UNIDADE', quantidade:'QUANTIDADE', minimo:'ESTOQUE MÍN.',
    custo:'CUSTO (R$)', validade:'VALIDADE', obs:'OBSERVAÇÕES',
    produto:'ID PRODUTO', produtoNome:'PRODUTO', fornecedor:'ID FORNECEDOR',
    fornecedorNome:'FORNECEDOR', profissional:'ID PROFISSIONAL',
    profissionalNome:'PROFISSIONAL', data:'DATA', motivo:'MOTIVO',
    produtos:'PRODUTOS FORNECIDOS', contato:'CONTATO',
  };
  const headerRow = headers.map(h => headerLabels[h] || h.toUpperCase());
  sheet.getRange(1, 1, 1, headers.length).setValues([headerRow]);

  try {
    const hRange = sheet.getRange(1, 1, 1, headers.length);
    hRange.setBackground(COR_ROSA);
    hRange.setFontColor(COR_BRANCO);
    hRange.setFontWeight('bold');
    hRange.setHorizontalAlignment('center');
    hRange.setFontSize(11);
    sheet.setFrozenRows(1);
  } catch(e) { Logger.log('Formatação ignorada: ' + e); }

  if (data && data.length > 0) {
    const rows = data.map(item =>
      headers.map(h => {
        const v = item[h];
        return (v === null || v === undefined) ? '' : v;
      })
    );
    sheet.getRange(2, 1, rows.length, headers.length).setValues(rows);

    try {
      for (let r = 2; r <= rows.length + 1; r++) {
        sheet.getRange(r, 1, 1, headers.length).setBackground(r % 2 === 0 ? COR_OFFWH : COR_BRANCO);
      }
    } catch(e) {}
  }

  try { sheet.autoResizeColumns(1, headers.length); } catch(e) {}
}

// ============= MESTRA =============
function calcularMestra(produtos, entradas, saidas) {
  return (produtos || []).map(p => {
    const totalEntradas = (entradas || [])
      .filter(e => e.produto === p.id)
      .reduce((s, e) => s + (Number(e.quantidade) || 0), 0);
    const totalSaidas = (saidas || [])
      .filter(s => s.produto === p.id)
      .reduce((s, sd) => s + (Number(sd.quantidade) || 0), 0);
    const estoqueAtual = Number(p.quantidade) || 0;
    const valorTotal   = estoqueAtual * (Number(p.custo) || 0);
    const status = estoqueAtual === 0 ? 'Zerado' : (estoqueAtual <= (Number(p.minimo) || 0) ? 'Baixo' : 'Normal');
    return {
      produto: p.nome, categoria: p.categoria, unidade: p.unidade,
      estoqueMinimo: p.minimo, totalEntradas, totalSaidas,
      estoqueAtual, custo: p.custo, valorTotal, status
    };
  });
}

function writeMestra(ss, mestra) {
  let sheet = ss.getSheetByName('Mestra');
  if (!sheet) sheet = ss.insertSheet('Mestra');

  sheet.clearContents();
  try { sheet.clearFormats(); } catch(e) {}

  try {
    sheet.getRange(1, 1, 1, 9).merge();
    sheet.getRange(1, 1).setValue('CLÍNICA LYARA RODRIGUES – POSIÇÃO DO ESTOQUE');
    sheet.getRange(1, 1).setBackground(COR_ROSA);
    sheet.getRange(1, 1).setFontColor(COR_BRANCO);
    sheet.getRange(1, 1).setFontWeight('bold');
    sheet.getRange(1, 1).setFontSize(13);
    sheet.getRange(1, 1).setHorizontalAlignment('center');
  } catch(e) {}

  const mHeaders = ['PRODUTO','CATEGORIA','UNIDADE','EST. MÍN.','ENTRADAS','SAÍDAS','EST. ATUAL','VALOR TOTAL','STATUS'];
  sheet.getRange(2, 1, 1, mHeaders.length).setValues([mHeaders]);
  try {
    const h2 = sheet.getRange(2, 1, 1, mHeaders.length);
    h2.setBackground(COR_MEDIA);
    h2.setFontColor(COR_BRANCO);
    h2.setFontWeight('bold');
    h2.setHorizontalAlignment('center');
    sheet.setFrozenRows(2);
  } catch(e) {}

  if (mestra.length > 0) {
    const rows = mestra.map(m => [
      m.produto, m.categoria, m.unidade, m.estoqueMinimo,
      m.totalEntradas, m.totalSaidas, m.estoqueAtual,
      'R$ ' + (m.valorTotal || 0).toFixed(2).replace('.', ','),
      m.status
    ]);
    sheet.getRange(3, 1, rows.length, mHeaders.length).setValues(rows);

    try {
      for (let r = 0; r < rows.length; r++) {
        const rowNum = r + 3;
        sheet.getRange(rowNum, 1, 1, mHeaders.length).setBackground(r % 2 === 0 ? COR_OFFWH : COR_BRANCO);
        const statusCell = sheet.getRange(rowNum, 9);
        const status = mestra[r].status;
        if (status === 'Zerado')     { statusCell.setBackground('#FECACA'); statusCell.setFontColor('#DC2626'); statusCell.setFontWeight('bold'); }
        else if (status === 'Baixo') { statusCell.setBackground('#FED7AA'); statusCell.setFontColor('#EA580C'); statusCell.setFontWeight('bold'); }
        else                         { statusCell.setBackground('#DCFCE7'); statusCell.setFontColor('#16A34A'); }
      }
    } catch(e) {}
  }

  try { sheet.autoResizeColumns(1, mHeaders.length); } catch(e) {}
}

// ============= SETUP INICIAL (execute uma vez) =============
function setupSpreadsheet() {
  const ss  = getSS();
  const uid = () => Utilities.getUuid().replace(/-/g, '').substring(0, 12);

  Logger.log('Iniciando configuração da planilha...');

  // Criar abas que não existem
  Object.keys(SHEET_NAMES).forEach(key => {
    const name = SHEET_NAMES[key];
    let sheet = ss.getSheetByName(name);
    if (!sheet) {
      if (name === 'Saídas') {
        sheet = ss.getSheetByName('Saidas') || ss.getSheetByName('Saída') || ss.getSheetByName('Saida');
      } else if (name === 'Produtos') {
        sheet = ss.getSheetByName('Produto') || ss.getSheetByName('produtos') || ss.getSheetByName('produto');
      } else if (name === 'Entradas') {
        sheet = ss.getSheetByName('Entrada') || ss.getSheetByName('entradas') || ss.getSheetByName('entrada');
      } else if (name === 'Profissionais') {
        sheet = ss.getSheetByName('Profissional') || ss.getSheetByName('profissionais') || ss.getSheetByName('profissional');
      } else if (name === 'Fornecedores') {
        sheet = ss.getSheetByName('Fornecedor') || ss.getSheetByName('fornecedores') || ss.getSheetByName('fornecedor');
      }
      if (sheet) {
        try { sheet.setName(name); } catch(e) {}
      } else {
        ss.insertSheet(name);
        Logger.log('Aba criada: ' + name);
      }
    }
  });

  // Profissionais
  const profSheet = ss.getSheetByName('Profissionais');
  if (profSheet.getLastRow() < 2) {
    const profissionais = [
      { id: uid(), nome: 'Tainara Santos',  especialidade: 'Esteticista',  registro: '', telefone: '', email: '', status: 'Ativo' },
      { id: uid(), nome: 'Thaís Oliveira',  especialidade: 'Biomédica',    registro: '', telefone: '', email: '', status: 'Ativo' },
      { id: uid(), nome: 'Carol Ferreira',  especialidade: 'Esteticista',  registro: '', telefone: '', email: '', status: 'Ativo' },
      { id: uid(), nome: 'Lyara Rodrigues', especialidade: 'Proprietária', registro: '', telefone: '', email: '', status: 'Ativo' },
    ];
    writeSheet(ss, 'Profissionais', HEADERS.profissionais, profissionais);
    Logger.log('Profissionais inseridas.');
  } else {
    Logger.log('Profissionais: aba já contém dados, mantendo.');
  }

  // Produtos
  const prodSheet   = ss.getSheetByName('Produtos');
  const lastProdRow = prodSheet.getLastRow();
  if (lastProdRow < 2) {
    const produtos = [
      { id: uid(), nome: 'Algodão (Rolo 500g)',        categoria: 'Materiais de Uso Geral', unidade: 'un', quantidade: 5, minimo: 5, custo: 15.90, validade: '', obs: 'Exemplo – adicione mais produtos' },
      { id: uid(), nome: 'Acetona Profissional 500ml', categoria: 'Materiais de Uso Geral', unidade: 'fr', quantidade: 6, minimo: 3, custo: 22.00, validade: '', obs: 'Exemplo – adicione mais produtos' },
    ];
    writeSheet(ss, 'Produtos', HEADERS.produtos, produtos);
    Logger.log('Produtos de exemplo inseridos.');
  } else {
    const firstHeader = prodSheet.getRange(1, 1).getValue();
    if (firstHeader.toString().toUpperCase() !== 'ID') {
      migrarProdutosAntigos(ss, uid);
    } else {
      Logger.log('Produtos: já no formato novo, mantendo.');
    }
  }

  // Entradas
  const entradaSheet = ss.getSheetByName('Entradas') || ss.getSheetByName('Entrada');
  if (entradaSheet) {
    if (entradaSheet.getName() === 'Entrada') entradaSheet.setName('Entradas');
    const hdr = entradaSheet.getLastRow() >= 1 ? entradaSheet.getRange(1,1).getValue().toString().toUpperCase() : '';
    if (hdr !== 'ID' && entradaSheet.getLastRow() > 1) migrarEntradasAntigas(ss, uid);
    else if (entradaSheet.getLastRow() < 1) writeSheet(ss, 'Entradas', HEADERS.entradas, []);
  } else {
    writeSheet(ss, 'Entradas', HEADERS.entradas, []);
  }

  // Saídas
  const saidaSheet = ss.getSheetByName('Saídas') || ss.getSheetByName('Saidas') || ss.getSheetByName('Saída') || ss.getSheetByName('Saida');
  if (saidaSheet) {
    if (saidaSheet.getName() !== 'Saídas') saidaSheet.setName('Saídas');
    const hdr = saidaSheet.getLastRow() >= 1 ? saidaSheet.getRange(1,1).getValue().toString().toUpperCase() : '';
    if (hdr !== 'ID' && saidaSheet.getLastRow() > 1) migrarSaidasAntigas(ss, uid);
    else if (saidaSheet.getLastRow() < 1) writeSheet(ss, 'Saídas', HEADERS.saidas, []);
  } else {
    writeSheet(ss, 'Saídas', HEADERS.saidas, []);
  }

  // Fornecedores
  const fornSheet = ss.getSheetByName('Fornecedores');
  if (fornSheet.getLastRow() < 1) writeSheet(ss, 'Fornecedores', HEADERS.fornecedores, []);

  // Mestra
  const allProds = readSheet(ss, 'Produtos',  HEADERS.produtos);
  const allEntr  = readSheet(ss, 'Entradas',  HEADERS.entradas);
  const allSaid  = readSheet(ss, 'Saídas',    HEADERS.saidas);
  try { writeMestra(ss, calcularMestra(allProds, allEntr, allSaid)); } catch(e) { Logger.log('Mestra: ' + e); }

  // Remove abas padrão
  ['Página1','Planilha1','Sheet1','Feuille 1'].forEach(name => {
    try {
      const s = ss.getSheetByName(name);
      if (s && ss.getNumSheets() > 1) ss.deleteSheet(s);
    } catch(e) {}
  });

  Logger.log('✅ Configuração concluída com sucesso! Agora implante como Web App.');
}

// ============= MIGRAÇÃO de dados antigos =============
function migrarProdutosAntigos(ss, uid) {
  Logger.log('Migrando Produtos antigos...');
  const sheet = ss.getSheetByName('Produtos');
  const data  = sheet.getDataRange().getValues();

  let headerRow = -1;
  for (let i = 0; i < data.length; i++) {
    if (data[i].some(c => c.toString().toLowerCase().includes('produto'))) { headerRow = i; break; }
  }
  if (headerRow < 0) return;

  const headers = data[headerRow].map(h => h.toString().toLowerCase().trim());
  const prodIdx = headers.findIndex(h => h.includes('produto'));
  const catIdx  = headers.findIndex(h => h.includes('categoria') || h.includes('categ'));
  const minIdx  = headers.findIndex(h => h.includes('mínimo') || h.includes('minimo') || h.includes('min'));
  const obsIdx  = headers.findIndex(h => h.includes('observ') || h.includes('obs'));

  const novos = [];
  for (let i = headerRow + 1; i < data.length; i++) {
    const row = data[i];
    if (!row[prodIdx]) continue;
    novos.push({
      id: uid(), nome: row[prodIdx] || '',
      categoria: catIdx >= 0 ? row[catIdx] : 'Insumos Gerais',
      unidade: 'un', quantidade: 0,
      minimo: minIdx >= 0 ? (Number(row[minIdx]) || 0) : 0,
      custo: 0, validade: '',
      obs: obsIdx >= 0 ? row[obsIdx] : '',
    });
  }
  writeSheet(ss, 'Produtos', HEADERS.produtos, novos);
  Logger.log('Migrados ' + novos.length + ' produtos.');
}

function migrarEntradasAntigas(ss, uid) {
  Logger.log('Migrando Entradas antigas...');
  const sheet = ss.getSheetByName('Entradas') || ss.getSheetByName('Entrada');
  if (!sheet) return;
  const data = sheet.getDataRange().getValues();
  if (data.length < 2) return;

  const novas = [];
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (!row[1]) continue;
    let dt = '';
    if (row[0] instanceof Date) dt = Utilities.formatDate(row[0], Session.getScriptTimeZone(), 'yyyy-MM-dd');
    else if (row[0]) dt = row[0].toString().split(' ')[0].split('/').reverse().join('-');
    novas.push({
      id: uid(), produto: '', produtoNome: row[1] || '',
      quantidade: Number(row[2]) || 0, custo: 0,
      data: dt, fornecedor: '', fornecedorNome: '',
      profissional: '', profissionalNome: '', obs: '',
    });
  }
  if (sheet.getName() === 'Entrada') sheet.setName('Entradas');
  writeSheet(ss, 'Entradas', HEADERS.entradas, novas);
  Logger.log('Migradas ' + novas.length + ' entradas.');
}

function migrarSaidasAntigas(ss, uid) {
  Logger.log('Migrando Saídas antigas...');
  const sheet = ss.getSheetByName('Saídas') || ss.getSheetByName('Saída');
  if (!sheet) return;
  const data = sheet.getDataRange().getValues();
  if (data.length < 2) return;

  const novas = [];
  for (let i = 1; i < data.length; i++) {
    const row = data[i];
    if (!row[2] && !row[1]) continue;
    let dt = '';
    if (row[0] instanceof Date) dt = Utilities.formatDate(row[0], Session.getScriptTimeZone(), 'yyyy-MM-dd');
    else if (row[0]) dt = row[0].toString().split(' ')[0].split('/').reverse().join('-');
    novas.push({
      id: uid(), produto: '', produtoNome: row[2] || row[1] || '',
      quantidade: Number(row[3]) || 0, data: dt,
      profissional: '', profissionalNome: row[1] || '',
      motivo: 'Uso em procedimento', obs: '',
    });
  }
  if (sheet.getName() === 'Saída') sheet.setName('Saídas');
  writeSheet(ss, 'Saídas', HEADERS.saidas, novas);
  Logger.log('Migradas ' + novas.length + ' saídas.');
}
