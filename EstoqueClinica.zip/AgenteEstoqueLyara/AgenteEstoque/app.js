/* =============================================
   CLÍNICA LYARA RODRIGUES – APP.JS
   Gestão de Estoque | Google Sheets Sync
   ============================================= */

// ========== CONFIG GOOGLE SHEETS ==========
const STORAGE_KEY = 'clinica_lyara_estoque';
const SHEETS_URL_KEY = 'lyara_sheets_url';

// URL padrão (deixe vazia para repositórios públicos por segurança)
const DEFAULT_SHEETS_URL = 'https://script.google.com/macros/s/AKfycbz9pA4wIiGhSXNywjpopWzLILh6gTTGd2GVXLLuW03eUh1d39ydApj-e5W8PLyr-iYSKg/exec';

let APPS_SCRIPT_URL = localStorage.getItem(SHEETS_URL_KEY) || DEFAULT_SHEETS_URL;
const OLD_SHEETS_URL = 'https://script.google.com/macros/s/AKfycbzYIzh38O4lgHdgkMGJhu-rF9eiIL8kJmK7NyPwN7NaH20V6ceuLHW1LktwVcYySsaTuA/exec';

// Se o usuário ainda estiver usando a URL antiga no cache local, atualiza automaticamente para a nova
if (APPS_SCRIPT_URL === OLD_SHEETS_URL) {
  APPS_SCRIPT_URL = DEFAULT_SHEETS_URL;
  localStorage.setItem(SHEETS_URL_KEY, DEFAULT_SHEETS_URL);
} else if (!localStorage.getItem(SHEETS_URL_KEY) && DEFAULT_SHEETS_URL) {
  localStorage.setItem(SHEETS_URL_KEY, DEFAULT_SHEETS_URL);
}

// ========== ESTADO GLOBAL ==========
let state = {
  produtos: [],
  entradas: [],
  saidas: [],
  profissionais: [],
  fornecedores: [],
};

let editingProduto = null;
let editingProfissional = null;
let editingFornecedor = null;
let confirmCallback = null;
let currentPage = 'dashboard';
let syncTimeout = null;
let showSyncOverlay = false;

// ========== PERSISTÊNCIA LOCAL ==========
function saveLocalState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function loadLocalState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) state = JSON.parse(raw);
  } catch (e) { console.warn('Erro ao carregar dados locais', e); }
}

// ========== GOOGLE SHEETS – LEITURA ==========
async function loadFromSheets() {
  if (!APPS_SCRIPT_URL) return false;
  try {
    setSyncStatus('loading');
    const url = APPS_SCRIPT_URL + '?action=getData&t=' + Date.now();
    const resp = await fetch(url, { method: 'GET' });
    if (!resp.ok) throw new Error('HTTP ' + resp.status);
    const data = await resp.json();
    if (data.error) throw new Error(data.error);

    // Merge: dados do Sheets sobreescrevem o local
    if (Array.isArray(data.profissionais)) state.profissionais = data.profissionais;
    if (Array.isArray(data.produtos)) state.produtos = data.produtos;
    if (Array.isArray(data.entradas)) state.entradas = data.entradas;
    if (Array.isArray(data.saidas)) state.saidas = data.saidas;
    if (Array.isArray(data.fornecedores)) state.fornecedores = data.fornecedores;

    // Converte tipos numéricos vindos do Sheets
    state.produtos = state.produtos.map(p => ({
      ...p,
      quantidade: Number(p.quantidade) || 0,
      minimo: Number(p.minimo) || 0,
      custo: Number(p.custo) || 0,
    }));
    state.entradas = state.entradas.map(e => ({ ...e, quantidade: Number(e.quantidade) || 0, custo: Number(e.custo) || 0 }));
    state.saidas = state.saidas.map(s => ({ ...s, quantidade: Number(s.quantidade) || 0 }));

    saveLocalState();
    setSyncStatus('synced');
    return true;
  } catch (err) {
    console.warn('Erro ao carregar do Sheets:', err);
    setSyncStatus('offline');
    return false;
  }
}

// ========== GOOGLE SHEETS – ESCRITA ==========
// Usa POST simples (text/plain para evitar preflight CORS)
async function syncToSheets(entity) {
  if (!APPS_SCRIPT_URL) return;
  try {
    setSyncStatus('syncing');
    await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      mode: 'no-cors',    // evita problemas CORS em file://
      body: JSON.stringify({
        action: 'save',
        entity: entity,
        data: state[entity],
        state: { // envia estado completo para recalcular Mestra
          produtos: state.produtos,
          entradas: state.entradas,
          saidas: state.saidas,
        }
      }),
    });
    // Com no-cors a resposta é opaca – assumimos sucesso otimisticamente
    setSyncStatus('synced');
  } catch (err) {
    console.warn('Erro ao sincronizar com Sheets:', err);
    setSyncStatus('offline');
  }
}

let syncQueue = [];
let isSyncing = false;
let syncHasError = false;

async function processSyncQueue() {
  if (isSyncing || syncQueue.length === 0) return;
  isSyncing = true;
  
  const entity = syncQueue[0];
  setSyncStatus('syncing');
  
  const labels = {
    produtos: 'produtos',
    entradas: 'entradas',
    saidas: 'saídas',
    profissionais: 'profissionais',
    fornecedores: 'fornecedores'
  };
  
  if (showSyncOverlay) {
    showLoadingOverlay(true, `Sincronizando ${labels[entity] || entity} com Google Sheets...`);
  }
  
  try {
    const resp = await fetch(APPS_SCRIPT_URL, {
      method: 'POST',
      body: JSON.stringify({
        action: 'save',
        entity: entity,
        data: state[entity],
        state: { // envia estado completo para recalcular Mestra
          produtos: state.produtos,
          entradas: state.entradas,
          saidas: state.saidas,
        }
      }),
    });

    if (!resp.ok) {
      throw new Error(`HTTP ${resp.status}`);
    }

    const resData = await resp.json();
    if (resData && resData.error) {
      throw new Error(resData.error);
    }

    setSyncStatus('synced');
    syncQueue.shift(); // Remove da fila após sucesso
  } catch (err) {
    console.warn(`Erro ao sincronizar ${entity}:`, err);
    setSyncStatus('offline');
    syncHasError = true;
    syncQueue.shift(); // Remove mesmo se falhar para não travar a fila
    showToast(`Falha ao sincronizar ${labels[entity] || entity}: ${err.message || err}`, 'error');
  }
  
  if (syncQueue.length === 0) {
    if (showSyncOverlay) {
      showLoadingOverlay(false);
      showSyncOverlay = false;
    }
    if (!syncHasError) {
      showToast('Planilha atualizada com sucesso!', 'success');
    } else {
      showToast('Sincronização concluída com falhas ou avisos.', 'error');
    }
  }
  
  isSyncing = false;
  // Processa o próximo item
  setTimeout(processSyncQueue, 100);
}

function scheduleSyncToSheets(entity) {
  saveLocalState();
  if (!APPS_SCRIPT_URL) return;
  
  if (syncQueue.length === 0) {
    syncHasError = false;
  }
  const queueWaiting = syncQueue.slice(isSyncing ? 1 : 0);
  if (!queueWaiting.includes(entity)) {
    syncQueue.push(entity);
  }
  processSyncQueue();
}

function syncAllToSheets() {
  saveLocalState();
  if (!APPS_SCRIPT_URL) return;
  
  syncHasError = false;
  const entities = ['produtos', 'entradas', 'saidas', 'profissionais', 'fornecedores'];
  entities.forEach(entity => {
    const queueWaiting = syncQueue.slice(isSyncing ? 1 : 0);
    if (!queueWaiting.includes(entity)) {
      syncQueue.push(entity);
    }
  });
  showSyncOverlay = true;
  processSyncQueue();
}

// ========== SYNC STATUS UI ==========
function setSyncStatus(status) {
  const dot = document.getElementById('syncDot');
  const text = document.getElementById('syncText');
  const map = {
    idle: { color: '#aaa', label: 'Local' },
    loading: { color: '#3b82f6', label: 'Carregando...' },
    syncing: { color: '#f59e0b', label: 'Sincronizando...' },
    pending: { color: '#f59e0b', label: 'Pendente' },
    synced: { color: '#BEDA90', label: 'Sincronizado ✓' }, // Usando o tom de verde BEDA90 solicitado pelo usuário
    offline: { color: '#ef4444', label: 'Offline' },
    error: { color: '#ef4444', label: 'Erro' },
  };
  const s = map[status] || map.idle;
  if (dot) { dot.style.background = s.color; dot.style.boxShadow = `0 0 6px ${s.color}`; }
  if (text) text.textContent = s.label;
}

// ========== CONFIG SHEETS ==========
function salvarConfig() {
  const url = (document.getElementById('sheetsUrlInput')?.value || '').trim();
  if (!url) { showToast('Cole a URL do Apps Script!', 'error'); return; }
  if (!url.startsWith('https://script.google.com')) {
    showToast('URL inválida. Use a URL do Apps Script.', 'error');
    return;
  }
  APPS_SCRIPT_URL = url;
  localStorage.setItem(SHEETS_URL_KEY, url);
  closeModal('modalConfig');
  document.getElementById('configBanner').style.display = 'none';
  showToast('Conectado! Carregando dados do Sheets...', 'success');
  loadAndRefresh();
}

function limparConfig() {
  APPS_SCRIPT_URL = '';
  localStorage.removeItem(SHEETS_URL_KEY);
  setSyncStatus('idle');
  closeModal('modalConfig');
  showToast('Desconectado do Google Sheets.', 'error');
}

async function loadAndRefresh() {
  showLoadingOverlay(true, 'Carregando dados do Google Sheets...');
  const ok = await loadFromSheets();
  showLoadingOverlay(false);
  if (ok) {
    showToast('Dados carregados do Google Sheets!', 'success');
    navigateTo(currentPage);
    renderDashboard();
  } else {
    showToast('Não foi possível conectar ao Google Sheets.', 'error');
  }
}

async function loadAndRefreshAndClose() {
  closeModal('modalConfig');
  await loadAndRefresh();
}

function syncAllAndClose() {
  closeModal('modalConfig');
  syncAllToSheets();
}

function showConfigForm() {
  document.getElementById('configConnectedWrapper').style.display = 'none';
  document.getElementById('configFormWrapper').style.display = 'block';
  renderConfigFooter(false);
}

function renderConfigFooter(connected) {
  const footer = document.getElementById('modalConfigFooter');
  if (!footer) return;
  if (connected) {
    footer.innerHTML = `
      <button class="btn-outline" onclick="closeModal('modalConfig')">Fechar</button>
      <button class="btn-outline" onclick="limparConfig()" style="color:#ef4444;border-color:#ef4444;margin-left:auto">Desconectar</button>
    `;
  } else {
    footer.innerHTML = `
      <button class="btn-outline" onclick="closeModal('modalConfig')">Cancelar</button>
      ${APPS_SCRIPT_URL ? `<button class="btn-outline" onclick="limparConfig()" style="color:#ef4444;border-color:#ef4444">Desconectar</button>` : ''}
      <button class="btn-primary" onclick="salvarConfig()">
        <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8l4 4 6-6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
        Salvar e Sincronizar
      </button>
    `;
  }
}

// ========== LOADING OVERLAY ==========
function showLoadingOverlay(show, text = 'Carregando dados do Google Sheets...') {
  const el = document.getElementById('loadingOverlay');
  if (el) {
    el.style.display = show ? 'flex' : 'none';
    const textEl = el.querySelector('.loading-text');
    if (textEl) textEl.textContent = text;
  }
}

// ========== NAVEGAÇÃO ==========
function navigateTo(page) {
  currentPage = page;
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));

  const pageEl = document.getElementById('page-' + page);
  const navEl = document.getElementById('nav-' + page);
  if (pageEl) pageEl.classList.add('active');
  if (navEl) navEl.classList.add('active');

  const titles = {
    dashboard: 'Dashboard',
    produtos: 'Produtos',
    entradas: 'Entradas',
    saidas: 'Saídas',
    profissionais: 'Profissionais',
    fornecedores: 'Fornecedores',
    relatorios: 'Relatórios',
  };
  document.getElementById('pageTitle').textContent = titles[page] || page;

  switch (page) {
    case 'dashboard': renderDashboard(); break;
    case 'produtos': renderProdutos(); break;
    case 'entradas': renderEntradas(); break;
    case 'saidas': renderSaidas(); break;
    case 'profissionais': renderProfissionais(); break;
    case 'fornecedores': renderFornecedores(); break;
  }

  document.getElementById('sidebar').classList.remove('mobile-open');
}

// ========== SIDEBAR TOGGLE ==========
document.getElementById('sidebarToggle').addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('collapsed');
  document.getElementById('mainWrapper').classList.toggle('expanded');
});

document.getElementById('menuBtn').addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('mobile-open');
});

document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    navigateTo(link.dataset.page);
  });
});

// ========== MODALS ==========
function openModal(id) {
  const modal = document.getElementById(id);
  if (!modal) return;

  // Preenche URL atual no modal de config e gerencia as visualizações
  if (id === 'modalConfig') {
    const input = document.getElementById('sheetsUrlInput');
    if (input) input.value = APPS_SCRIPT_URL;

    if (APPS_SCRIPT_URL) {
      document.getElementById('configConnectedWrapper').style.display = 'block';
      document.getElementById('configFormWrapper').style.display = 'none';
      renderConfigFooter(true);
    } else {
      document.getElementById('configConnectedWrapper').style.display = 'none';
      document.getElementById('configFormWrapper').style.display = 'block';
      renderConfigFooter(false);
    }
  }

  modal.classList.add('open');

  if (id === 'modalProduto') {
    populateSelectFornecedores('produtoFornecedor');
  }
  if (id === 'modalEntrada') {
    populateSelectProdutos('entradaProduto');
    populateSelectFornecedores('entradaFornecedor');
    populateSelectProfissionais('entradaProfissional', false);
    document.getElementById('entradaData').value = today();
  }
  if (id === 'modalSaida') {
    populateSelectProdutos('saidaProduto');
    populateSelectProfissionais('saidaProfissional', true);
    document.getElementById('saidaData').value = today();
    document.getElementById('saidaDisponivel').textContent = '–';
  }
}

function closeModal(id) {
  const modal = document.getElementById(id);
  if (!modal) return;
  modal.classList.remove('open');
  const form = modal.querySelector('form');
  if (form) form.reset();
  editingProduto = null;
  editingProfissional = null;
  editingFornecedor = null;
  const ids = ['produtoEditId', 'profEditId', 'fornEditId'];
  ids.forEach(eid => { const el = document.getElementById(eid); if (el) el.value = ''; });
  const titulos = {
    modalProduto: 'modalProdutoTitulo', modalProfissional: 'modalProfTitulo',
    modalFornecedor: 'modalFornTitulo'
  };
  const tKey = titulos[id];
  if (tKey) {
    const tMap = { modalProdutoTitulo: 'Novo Produto', modalProfTitulo: 'Novo Profissional', modalFornTitulo: 'Novo Fornecedor' };
    const el = document.getElementById(tKey);
    if (el) el.textContent = tMap[tKey] || '';
  }
}

document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closeModal(overlay.id);
  });
});

// ========== TOAST ==========
function showToast(msg, type = 'default') {
  const toast = document.getElementById('toast');
  const msgEl = document.getElementById('toastMsg');
  toast.textContent = '';
  if (msgEl) msgEl.textContent = msg; else toast.textContent = msg;
  toast.className = 'toast show ' + type;
  setTimeout(() => { toast.className = 'toast'; }, 3400);
}

// ========== CONFIRM ==========
function showConfirm(msg, cb) {
  document.getElementById('confirmMsg').textContent = msg;
  confirmCallback = cb;
  document.getElementById('modalConfirm').classList.add('open');
}

document.getElementById('confirmBtn').addEventListener('click', () => {
  if (confirmCallback) confirmCallback();
  confirmCallback = null;
  closeModal('modalConfirm');
});

// ========== UTILITIES ==========
function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

function today() {
  return new Date().toISOString().split('T')[0];
}

function fmtDate(d) {
  if (!d) return '–';
  const s = String(d).trim();
  if (s.includes('-')) {
    const parts = s.split('-');
    if (parts.length === 3) {
      const [y, m, dd] = parts;
      return `${dd}/${m}/${y}`;
    }
  }
  if (s.includes('/')) {
    const parts = s.split('/');
    if (parts.length === 3 && parts[2].length === 4) {
      return s; // Já está no formato dd/mm/yyyy
    }
  }
  return d;
}

function parseDateForSort(d) {
  if (!d) return new Date(0);
  const s = String(d).trim();
  if (s.includes('-')) {
    const parts = s.split('-');
    if (parts.length === 3) {
      return new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]));
    }
  }
  if (s.includes('/')) {
    const parts = s.split('/');
    if (parts.length === 3) {
      return new Date(Number(parts[2]), Number(parts[1]) - 1, Number(parts[0]));
    }
  }
  const parsed = new Date(s);
  return isNaN(parsed.getTime()) ? new Date(0) : parsed;
}

function fmtCurrency(val) {
  return 'R$ ' + (Number(val) || 0).toFixed(2).replace('.', ',');
}

function initials(name) {
  if (!name) return '?';
  return name.split(' ').slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

function getStatusEstoque(prod) {
  const q = Number(prod.quantidade) || 0;
  const m = Number(prod.minimo) || 0;
  if (q === 0) return 'zerado';
  if (m > 0 && q <= m) return 'baixo';
  return 'normal';
}

function statusLabel(s) {
  return { normal: 'Normal', baixo: 'Baixo', zerado: 'Zerado', ativo: 'Ativo', inativo: 'Inativo' }[s] || s;
}

function today_display() {
  return new Date().toLocaleDateString('pt-BR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
}

// ========== POPULATE SELECTS ==========
function populateSelectProdutos(selectId) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  const cur = sel.value;
  sel.innerHTML = '<option value="">Selecione um produto...</option>';
  state.produtos.forEach(p => {
    const o = document.createElement('option');
    o.value = p.id;
    o.textContent = `${p.nome} (${Number(p.quantidade) || 0} ${p.unidade})`;
    sel.appendChild(o);
  });
  if (cur) sel.value = cur;
}

function populateSelectFornecedores(selectId) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  sel.innerHTML = '<option value="">Nenhum</option>';
  state.fornecedores.forEach(f => {
    const o = document.createElement('option');
    o.value = f.id;
    o.textContent = f.nome;
    sel.appendChild(o);
  });
}

function populateSelectProfissionais(selectId, required) {
  const sel = document.getElementById(selectId);
  if (!sel) return;
  sel.innerHTML = required ? '<option value="">Selecione...</option>' : '<option value="">Nenhum</option>';

  const targetNames = ['Carol', 'Tainara', 'Tais', 'Lyara'];

  if (selectId === 'saidaProfissional') {
    // Para a saída, mostramos exatamente Carol, Tainara, Tais, Lyara
    targetNames.forEach(name => {
      const p = state.profissionais.find(x => 
        x.nome.toLowerCase().includes(name.toLowerCase()) || 
        (name === 'Tais' && x.nome.toLowerCase().includes('thaís')) ||
        (name === 'Tais' && x.nome.toLowerCase().includes('tais'))
      );
      const o = document.createElement('option');
      o.value = p ? p.id : name; // Associa ao ID correspondente na planilha se houver
      o.textContent = name;
      sel.appendChild(o);
    });
  } else {
    // Para outras telas, mostra a lista completa ativa
    state.profissionais.filter(p => p.status === 'Ativo').forEach(p => {
      const o = document.createElement('option');
      o.value = p.id;
      o.textContent = p.nome;
      sel.appendChild(o);
    });
  }
}

// ========== DASHBOARD ==========
function renderDashboard() {
  document.getElementById('currentDate').textContent = today_display();

  const total = state.produtos.length;
  const baixo = state.produtos.filter(p => getStatusEstoque(p) !== 'normal').length;
  const profQty = state.profissionais.filter(p => p.status === 'Ativo').length;

  animateValue('kpi-total', total);
  animateValue('kpi-baixo', baixo);
  animateValue('kpi-prof', profQty);

  const badge = document.getElementById('notifBadge');
  badge.textContent = baixo || 0;
  badge.style.display = baixo ? 'flex' : 'none';

  // Movimentações recentes
  const all = [
    ...state.entradas.map(e => ({ ...e, tipo: 'entrada' })),
    ...state.saidas.map(s => ({ ...s, tipo: 'saida' })),
  ].sort((a, b) => parseDateForSort(b.data) - parseDateForSort(a.data)).slice(0, 10);

  const actList = document.getElementById('activityList');
  if (all.length === 0) {
    actList.innerHTML = '<p class="empty-state">Nenhuma movimentação registrada ainda.</p>';
  } else {
    actList.innerHTML = all.map(item => {
      const prod = state.produtos.find(p => p.id === item.produto);
      const prof = state.profissionais.find(p => p.id === item.profissional);
      const nome = prod?.nome || item.produtoNome || '–';
      const tipo = item.tipo;
      const sinal = tipo === 'entrada' ? '+' : '-';
      return `
        <div class="activity-item">
          <div class="activity-dot ${tipo}"></div>
          <div class="activity-info">
            <div class="activity-product">${nome}</div>
            <div class="activity-meta">${fmtDate(item.data)}${prof ? ' · ' + prof.nome : ''}</div>
          </div>
          <span class="activity-qty ${tipo}">${sinal}${item.quantidade}</span>
        </div>`;
    }).join('');
  }

  // Estoque crítico
  const criticals = state.produtos.filter(p => getStatusEstoque(p) !== 'normal');
  const critList = document.getElementById('criticalList');
  if (criticals.length === 0) {
    critList.innerHTML = '<p class="empty-state">Nenhum produto em situação crítica. ✓</p>';
  } else {
    critList.innerHTML = criticals.map(p => `
      <div class="critical-item">
        <div>
          <div class="critical-name">${p.nome}</div>
          <div class="critical-qty">${p.categoria}</div>
        </div>
        <span class="status-badge status-${getStatusEstoque(p)}">${Number(p.quantidade) || 0} ${p.unidade}</span>
      </div>`).join('');
  }
}

function animateValue(id, target) {
  const el = document.getElementById(id);
  if (!el) return;
  let start = 0;
  const step = Math.ceil(target / 20) || 1;
  const timer = setInterval(() => {
    start = Math.min(start + step, target);
    el.textContent = start;
    if (start >= target) clearInterval(timer);
  }, 30);
}

// ========== PRODUTOS ==========
function renderProdutos() {
  const tbody = document.getElementById('tbodyProdutos');
  if (!tbody) return;

  const search = (document.getElementById('searchProduto')?.value || '').toLowerCase();
  const catF = (document.getElementById('filterCategoria')?.value || '');
  const estF = (document.getElementById('filterEstoque')?.value || '');

  const filtered = state.produtos.filter(p => {
    const ms = !search || p.nome.toLowerCase().includes(search) || (p.categoria || '').toLowerCase().includes(search);
    const mc = !catF || p.categoria === catF;
    const me = !estF || getStatusEstoque(p) === estF;
    return ms && mc && me;
  });

  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="7" class="empty-row">Nenhum produto encontrado.</td></tr>';
  } else {
    tbody.innerHTML = filtered.map(p => {
      const status = getStatusEstoque(p);
      return `
        <tr>
          <td>
            <div class="product-table-name">${p.nome}</div>
            ${p.fornecedorNome ? `<div style="font-size:0.76rem;color:#888">Forn: ${p.fornecedorNome}</div>` : ''}
            ${p.validade ? `<div style="font-size:0.76rem;color:#888">Val: ${fmtDate(p.validade)}</div>` : ''}
          </td>
          <td>${p.categoria || '–'}</td>
          <td><strong>${Number(p.quantidade) || 0}</strong> ${p.unidade}</td>
          <td>${Number(p.minimo) || 0} ${p.unidade}</td>
          <td>${fmtCurrency(p.custo)}</td>
          <td><span class="status-badge status-${status}">${statusLabel(status)}</span></td>
          <td>
            <div class="action-btns">
              <button class="btn-icon" onclick="editProduto('${p.id}')">
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M8.5 1.5L10.5 3.5l-7 7H1.5v-2L8.5 1.5z" stroke="currentColor" stroke-width="1.2"/></svg>
                Editar
              </button>
              <button class="btn-icon delete" onclick="deleteProduto('${p.id}')">
                <svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M1.5 3h9M4 3V2h4v1M5 5v4M7 5v4" stroke="currentColor" stroke-width="1.2" stroke-linecap="round"/></svg>
                Excluir
              </button>
            </div>
          </td>
        </tr>`;
    }).join('');
  }

  // Atualiza filtro de categorias
  const catSel = document.getElementById('filterCategoria');
  const cats = [...new Set(state.produtos.map(p => p.categoria).filter(Boolean))];
  const curCat = catSel.value;
  catSel.innerHTML = '<option value="">Todas as categorias</option>' +
    cats.map(c => `<option value="${c}"${c === curCat ? ' selected' : ''}>${c}</option>`).join('');

  // Datalist
  const dl = document.getElementById('categoriasList');
  if (dl) dl.innerHTML = cats.map(c => `<option value="${c}"/>`).join('');
}

function salvarProduto(e) {
  e.preventDefault();
  const id = document.getElementById('produtoEditId').value;
  const fornId = document.getElementById('produtoFornecedor').value;
  const forn = state.fornecedores.find(f => f.id === fornId);
  const data = {
    id: id || uid(),
    nome: document.getElementById('produtoNome').value.trim(),
    categoria: document.getElementById('produtoCategoria').value.trim(),
    unidade: document.getElementById('produtoUnidade').value,
    quantidade: Number(document.getElementById('produtoQtd').value) || 0,
    minimo: Number(document.getElementById('produtoMinimo').value) || 0,
    custo: Number(document.getElementById('produtoCusto').value) || 0,
    validade: document.getElementById('produtoValidade').value,
    fornecedor: fornId || '',
    fornecedorNome: forn?.nome || '',
    obs: document.getElementById('produtoObs').value.trim(),
  };

  if (id) {
    const idx = state.produtos.findIndex(p => p.id === id);
    if (idx >= 0) state.produtos[idx] = data;
    showToast('Produto atualizado!', 'success');
  } else {
    state.produtos.push(data);
    showToast('Produto cadastrado!', 'success');
  }

  scheduleSyncToSheets('produtos');
  closeModal('modalProduto');
  renderProdutos();
  renderDashboard();
}

function editProduto(id) {
  const p = state.produtos.find(x => x.id === id);
  if (!p) return;
  
  populateSelectFornecedores('produtoFornecedor');
  
  document.getElementById('produtoEditId').value = p.id;
  document.getElementById('produtoNome').value = p.nome;
  document.getElementById('produtoCategoria').value = p.categoria;
  document.getElementById('produtoUnidade').value = p.unidade;
  document.getElementById('produtoQtd').value = p.quantidade;
  document.getElementById('produtoMinimo').value = p.minimo;
  document.getElementById('produtoCusto').value = p.custo;
  document.getElementById('produtoValidade').value = p.validade;
  document.getElementById('produtoFornecedor').value = p.fornecedor || '';
  document.getElementById('produtoObs').value = p.obs;
  document.getElementById('modalProdutoTitulo').textContent = 'Editar Produto';
  openModal('modalProduto');
}

function deleteProduto(id) {
  const p = state.produtos.find(x => x.id === id);
  showConfirm(`Deseja excluir o produto "${p?.nome}"? Esta ação não pode ser desfeita.`, () => {
    state.produtos = state.produtos.filter(x => x.id !== id);
    scheduleSyncToSheets('produtos');
    renderProdutos();
    renderDashboard();
    showToast('Produto excluído.', 'error');
  });
}

// ========== ENTRADAS ==========
function renderEntradas() {
  const tbody = document.getElementById('tbodyEntradas');
  if (!tbody) return;

  const search = (document.getElementById('searchEntrada')?.value || '').toLowerCase();
  const dateF = (document.getElementById('filterEntradaData')?.value || '');

  const filtered = state.entradas.filter(e => {
    const prod = state.produtos.find(p => p.id === e.produto);
    const nome = prod?.nome || e.produtoNome || '';
    return (!search || nome.toLowerCase().includes(search)) && (!dateF || e.data === dateF);
  }).sort((a, b) => parseDateForSort(b.data) - parseDateForSort(a.data));

  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="8" class="empty-row">Nenhuma entrada registrada.</td></tr>';
  } else {
    tbody.innerHTML = filtered.map(e => {
      const prod = state.produtos.find(p => p.id === e.produto);
      const forn = state.fornecedores.find(f => f.id === e.fornecedor);
      const prof = state.profissionais.find(p => p.id === e.profissional);
      const total = (Number(e.quantidade) || 0) * (Number(e.custo) || 0);
      return `
        <tr>
          <td>${fmtDate(e.data)}</td>
          <td><strong>${prod?.nome || e.produtoNome || '–'}</strong></td>
          <td><span style="font-weight:700;color:var(--green)">+${e.quantidade}</span></td>
          <td>${fmtCurrency(e.custo)}</td>
          <td>${fmtCurrency(total)}</td>
          <td>${forn?.nome || e.fornecedorNome || '–'}</td>
          <td>${prof?.nome || e.profissionalNome || '–'}</td>
          <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${e.obs || '–'}</td>
        </tr>`;
    }).join('');
  }
}

function salvarEntrada(e) {
  e.preventDefault();
  const prodId = document.getElementById('entradaProduto').value;
  const qty = Number(document.getElementById('entradaQtd').value) || 0;
  if (!prodId || qty <= 0) { showToast('Selecione um produto e informe a quantidade.', 'error'); return; }

  const fornId = document.getElementById('entradaFornecedor').value;
  const profId = document.getElementById('entradaProfissional').value;
  const forn = state.fornecedores.find(f => f.id === fornId);
  const prof = state.profissionais.find(p => p.id === profId);
  const prod = state.produtos.find(p => p.id === prodId);

  const entrada = {
    id: uid(),
    produto: prodId,
    produtoNome: prod?.nome || '',
    quantidade: qty,
    custo: Number(document.getElementById('entradaCusto').value) || 0,
    data: document.getElementById('entradaData').value,
    fornecedor: fornId || '',
    fornecedorNome: forn?.nome || '',
    profissional: profId || '',
    profissionalNome: prof?.nome || profId || '',
    obs: document.getElementById('entradaObs').value.trim(),
  };

  // Atualiza estoque
  const idx = state.produtos.findIndex(p => p.id === prodId);
  if (idx >= 0) {
    state.produtos[idx].quantidade = (Number(state.produtos[idx].quantidade) || 0) + qty;
    if (entrada.custo > 0) state.produtos[idx].custo = entrada.custo;
  }

  state.entradas.push(entrada);
  scheduleSyncToSheets('entradas');
  scheduleSyncToSheets('produtos');
  closeModal('modalEntrada');
  renderEntradas();
  renderDashboard();
  showToast(`Entrada de ${qty} unidade(s) registrada!`, 'success');
}

// ========== SAÍDAS ==========
function atualizarDisponivel() {
  const id = document.getElementById('saidaProduto').value;
  const prod = state.produtos.find(p => p.id === id);
  document.getElementById('saidaDisponivel').textContent =
    prod ? `${Number(prod.quantidade) || 0} ${prod.unidade}` : '–';
}

function renderSaidas() {
  const tbody = document.getElementById('tbodySaidas');
  if (!tbody) return;

  const search = (document.getElementById('searchSaida')?.value || '').toLowerCase();
  const dateF = (document.getElementById('filterSaidaData')?.value || '');

  const filtered = state.saidas.filter(s => {
    const prod = state.produtos.find(p => p.id === s.produto);
    const nome = prod?.nome || s.produtoNome || '';
    return (!search || nome.toLowerCase().includes(search)) && (!dateF || s.data === dateF);
  }).sort((a, b) => parseDateForSort(b.data) - parseDateForSort(a.data));

  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty-row">Nenhuma saída registrada.</td></tr>';
  } else {
    tbody.innerHTML = filtered.map(s => {
      const prod = state.produtos.find(p => p.id === s.produto);
      const prof = state.profissionais.find(p => p.id === s.profissional);
      return `
        <tr>
          <td>${fmtDate(s.data)}</td>
          <td><strong>${prod?.nome || s.produtoNome || '–'}</strong></td>
          <td><span style="font-weight:700;color:var(--orange)">-${s.quantidade}</span></td>
          <td>${prof?.nome || s.profissionalNome || '–'}</td>
          <td>${s.motivo || '–'}</td>
          <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${s.obs || '–'}</td>
        </tr>`;
    }).join('');
  }
}

function salvarSaida(e) {
  e.preventDefault();
  const prodId = document.getElementById('saidaProduto').value;
  const qty = Number(document.getElementById('saidaQtd').value) || 0;
  const profId = document.getElementById('saidaProfissional').value;

  if (!prodId || qty <= 0) { showToast('Selecione um produto e informe a quantidade.', 'error'); return; }
  if (!profId) { showToast('Selecione o profissional responsável.', 'error'); return; }

  const prod = state.produtos.find(p => p.id === prodId);
  if (!prod || (Number(prod.quantidade) || 0) < qty) {
    showToast('Quantidade indisponível no estoque!', 'error'); return;
  }

  const prof = state.profissionais.find(p => p.id === profId);
  const saida = {
    id: uid(),
    produto: prodId,
    produtoNome: prod?.nome || '',
    quantidade: qty,
    data: document.getElementById('saidaData').value,
    profissional: profId,
    profissionalNome: prof?.nome || profId || '',
    motivo: document.getElementById('saidaMotivo').value,
    obs: document.getElementById('saidaObs').value.trim(),
  };

  prod.quantidade = (Number(prod.quantidade) || 0) - qty;
  state.saidas.push(saida);
  scheduleSyncToSheets('saidas');
  scheduleSyncToSheets('produtos');
  closeModal('modalSaida');
  renderSaidas();
  renderDashboard();
  showToast(`Saída de ${qty} unidade(s) registrada!`, 'success');
}

// ========== PROFISSIONAIS ==========
function renderProfissionais() {
  const grid = document.getElementById('gridProfissionais');
  if (!grid) return;

  const search = (document.getElementById('searchProfissional')?.value || '').toLowerCase();
  const espF = (document.getElementById('filterEspecialidade')?.value || '');

  const filtered = state.profissionais.filter(p => {
    const ms = !search || p.nome.toLowerCase().includes(search) || (p.especialidade || '').toLowerCase().includes(search);
    const me = !espF || p.especialidade === espF;
    return ms && me;
  });

  if (filtered.length === 0) {
    grid.innerHTML = '<p class="empty-state">Nenhum profissional encontrado.</p>';
  } else {
    grid.innerHTML = filtered.map(p => `
      <div class="prof-card">
        <div class="prof-header">
          <div class="prof-avatar">${initials(p.nome)}</div>
          <div class="prof-info">
            <div class="prof-name">${p.nome}</div>
            <div class="prof-esp">${p.especialidade || '–'}</div>
          </div>
          <span class="status-badge status-${(p.status || 'Ativo').toLowerCase()}" style="margin-left:auto">${p.status || 'Ativo'}</span>
        </div>
        <div class="prof-details">
          ${p.registro ? `<div class="prof-detail">📋 ${p.registro}</div>` : ''}
          ${p.telefone ? `<div class="prof-detail">📞 ${p.telefone}</div>` : ''}
          ${p.email ? `<div class="prof-detail">✉ ${p.email}</div>` : ''}
        </div>
        <div class="prof-actions">
          <button class="btn-icon" onclick="editProfissional('${p.id}')">✏ Editar</button>
          <button class="btn-icon delete" onclick="deleteProfissional('${p.id}')">🗑 Excluir</button>
        </div>
      </div>`).join('');
  }

  // Atualiza filtro de especialidades
  const espSel = document.getElementById('filterEspecialidade');
  const esps = [...new Set(state.profissionais.map(p => p.especialidade).filter(Boolean))];
  const curEsp = espSel.value;
  espSel.innerHTML = '<option value="">Todas as especialidades</option>' +
    esps.map(s => `<option value="${s}"${s === curEsp ? ' selected' : ''}>${s}</option>`).join('');
}

function salvarProfissional(e) {
  e.preventDefault();
  const id = document.getElementById('profEditId').value;
  const data = {
    id: id || uid(),
    nome: document.getElementById('profNome').value.trim(),
    especialidade: document.getElementById('profEspecialidade').value.trim(),
    registro: document.getElementById('profRegistro').value.trim(),
    telefone: document.getElementById('profTelefone').value.trim(),
    email: document.getElementById('profEmail').value.trim(),
    status: document.getElementById('profStatus').value,
  };

  if (id) {
    const idx = state.profissionais.findIndex(p => p.id === id);
    if (idx >= 0) state.profissionais[idx] = data;
    showToast('Profissional atualizado!', 'success');
  } else {
    state.profissionais.push(data);
    showToast('Profissional cadastrada!', 'success');
  }

  scheduleSyncToSheets('profissionais');
  closeModal('modalProfissional');
  renderProfissionais();
  renderDashboard();
}

function editProfissional(id) {
  const p = state.profissionais.find(x => x.id === id);
  if (!p) return;
  document.getElementById('profEditId').value = p.id;
  document.getElementById('profNome').value = p.nome;
  document.getElementById('profEspecialidade').value = p.especialidade;
  document.getElementById('profRegistro').value = p.registro;
  document.getElementById('profTelefone').value = p.telefone;
  document.getElementById('profEmail').value = p.email;
  document.getElementById('profStatus').value = p.status;
  document.getElementById('modalProfTitulo').textContent = 'Editar Profissional';
  openModal('modalProfissional');
}

function deleteProfissional(id) {
  const p = state.profissionais.find(x => x.id === id);
  showConfirm(`Deseja excluir a profissional "${p?.nome}"?`, () => {
    state.profissionais = state.profissionais.filter(x => x.id !== id);
    scheduleSyncToSheets('profissionais');
    renderProfissionais();
    renderDashboard();
    showToast('Profissional excluída.', 'error');
  });
}

// ========== FORNECEDORES ==========
function renderFornecedores() {
  const tbody = document.getElementById('tbodyFornecedores');
  if (!tbody) return;

  const search = (document.getElementById('searchFornecedor')?.value || '').toLowerCase();
  const filtered = state.fornecedores.filter(f =>
    !search || f.nome.toLowerCase().includes(search) || (f.contato || '').toLowerCase().includes(search)
  );

  if (filtered.length === 0) {
    tbody.innerHTML = '<tr><td colspan="6" class="empty-row">Nenhum fornecedor cadastrado.</td></tr>';
  } else {
    tbody.innerHTML = filtered.map(f => `
      <tr>
        <td><strong>${f.nome}</strong></td>
        <td>${f.contato || '–'}</td>
        <td>${f.telefone || '–'}</td>
        <td>${f.email || '–'}</td>
        <td style="max-width:160px;overflow:hidden;text-overflow:ellipsis">${f.produtos || '–'}</td>
        <td>
          <div class="action-btns">
            <button class="btn-icon" onclick="editFornecedor('${f.id}')">✏ Editar</button>
            <button class="btn-icon delete" onclick="deleteFornecedor('${f.id}')">🗑 Excluir</button>
          </div>
        </td>
      </tr>`).join('');
  }
}

function salvarFornecedor(e) {
  e.preventDefault();
  const id = document.getElementById('fornEditId').value;
  const data = {
    id: id || uid(),
    nome: document.getElementById('fornNome').value.trim(),
    contato: document.getElementById('fornContato').value.trim(),
    telefone: document.getElementById('fornTelefone').value.trim(),
    email: document.getElementById('fornEmail').value.trim(),
    produtos: document.getElementById('fornProdutos').value.trim(),
  };

  if (id) {
    const idx = state.fornecedores.findIndex(f => f.id === id);
    if (idx >= 0) state.fornecedores[idx] = data;
    showToast('Fornecedor atualizado!', 'success');
  } else {
    state.fornecedores.push(data);
    showToast('Fornecedor cadastrado!', 'success');
  }

  scheduleSyncToSheets('fornecedores');
  closeModal('modalFornecedor');
  renderFornecedores();
}

function editFornecedor(id) {
  const f = state.fornecedores.find(x => x.id === id);
  if (!f) return;
  document.getElementById('fornEditId').value = f.id;
  document.getElementById('fornNome').value = f.nome;
  document.getElementById('fornContato').value = f.contato;
  document.getElementById('fornTelefone').value = f.telefone;
  document.getElementById('fornEmail').value = f.email;
  document.getElementById('fornProdutos').value = f.produtos;
  document.getElementById('modalFornTitulo').textContent = 'Editar Fornecedor';
  openModal('modalFornecedor');
}

function deleteFornecedor(id) {
  const f = state.fornecedores.find(x => x.id === id);
  showConfirm(`Deseja excluir o fornecedor "${f?.nome}"?`, () => {
    state.fornecedores = state.fornecedores.filter(x => x.id !== id);
    scheduleSyncToSheets('fornecedores');
    renderFornecedores();
    showToast('Fornecedor excluído.', 'error');
  });
}

// ========== RELATÓRIOS ==========
function gerarRelatorio(tipo) {
  const area = document.getElementById('relatorioArea');
  const titulo = document.getElementById('relatorioTitulo');
  const conteudo = document.getElementById('relatorioConteudo');
  area.style.display = 'block';
  area.scrollIntoView({ behavior: 'smooth' });

  const tipos = {
    estoque: 'Estoque Atual',
    entradas: 'Relatório de Entradas',
    saidas: 'Relatório de Saídas',
    profissionais: 'Consumo por Profissional',
  };
  titulo.textContent = tipos[tipo] || tipo;

  let html = '';

  if (tipo === 'estoque') {
    html = `<div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Produto</th><th>Categoria</th><th>Quantidade</th><th>Mín.</th><th>Custo Unit.</th><th>Valor Total</th><th>Status</th></tr></thead>
        <tbody>${state.produtos.length === 0 ? '<tr><td colspan="7" class="empty-row">Sem produtos.</td></tr>' :
        state.produtos.map(p => {
          const s = getStatusEstoque(p);
          const vt = (Number(p.quantidade) || 0) * (Number(p.custo) || 0);
          return `<tr>
              <td><strong>${p.nome}</strong></td>
              <td>${p.categoria || '–'}</td>
              <td>${Number(p.quantidade) || 0} ${p.unidade}</td>
              <td>${Number(p.minimo) || 0}</td>
              <td>${fmtCurrency(p.custo)}</td>
              <td>${fmtCurrency(vt)}</td>
              <td><span class="status-badge status-${s}">${statusLabel(s)}</span></td>
            </tr>`;
        }).join('')}
        </tbody>
      </table></div>
      <div style="margin-top:12px;padding:12px 16px;background:var(--pink-light);border-radius:8px;font-weight:600;color:var(--pink-dark)">
        Valor total em estoque: ${fmtCurrency(state.produtos.reduce((s, p) => s + (Number(p.quantidade) || 0) * (Number(p.custo) || 0), 0))}
      </div>`;

  } else if (tipo === 'entradas') {
    const sorted = [...state.entradas].sort((a, b) => parseDateForSort(b.data) - parseDateForSort(a.data));
    html = `<div class="table-wrap"><table class="data-table">
      <thead><tr><th>Data</th><th>Produto</th><th>Qtd</th><th>Custo Unit.</th><th>Total</th><th>Fornecedor</th><th>Profissional</th></tr></thead>
      <tbody>${sorted.length === 0 ? '<tr><td colspan="7" class="empty-row">Sem entradas.</td></tr>' :
        sorted.map(e => {
          const p = state.produtos.find(x => x.id === e.produto);
          const f = state.fornecedores.find(x => x.id === e.fornecedor);
          const pr = state.profissionais.find(x => x.id === e.profissional);
          const t = (Number(e.quantidade) || 0) * (Number(e.custo) || 0);
          return `<tr>
            <td>${fmtDate(e.data)}</td>
            <td>${p?.nome || e.produtoNome || '–'}</td>
            <td style="color:var(--green);font-weight:700">+${e.quantidade}</td>
            <td>${fmtCurrency(e.custo)}</td>
            <td>${fmtCurrency(t)}</td>
            <td>${f?.nome || e.fornecedorNome || '–'}</td>
            <td>${pr?.nome || e.profissionalNome || '–'}</td>
          </tr>`;
        }).join('')}
      </tbody></table></div>`;

  } else if (tipo === 'saidas') {
    const sorted = [...state.saidas].sort((a, b) => parseDateForSort(b.data) - parseDateForSort(a.data));
    html = `<div class="table-wrap"><table class="data-table">
      <thead><tr><th>Data</th><th>Produto</th><th>Qtd</th><th>Profissional</th><th>Motivo</th></tr></thead>
      <tbody>${sorted.length === 0 ? '<tr><td colspan="5" class="empty-row">Sem saídas.</td></tr>' :
        sorted.map(s => {
          const p = state.produtos.find(x => x.id === s.produto);
          const pr = state.profissionais.find(x => x.id === s.profissional);
          return `<tr>
            <td>${fmtDate(s.data)}</td>
            <td>${p?.nome || s.produtoNome || '–'}</td>
            <td style="color:var(--orange);font-weight:700">-${s.quantidade}</td>
            <td>${pr?.nome || s.profissionalNome || '–'}</td>
            <td>${s.motivo || '–'}</td>
          </tr>`;
        }).join('')}
      </tbody></table></div>`;

  } else if (tipo === 'profissionais') {
    const byProf = {};
    state.saidas.forEach(s => {
      const pr = state.profissionais.find(x => x.id === s.profissional);
      const key = pr?.nome || s.profissionalNome || 'Não informado';
      if (!byProf[key]) byProf[key] = { total: 0, itens: 0 };
      byProf[key].total += Number(s.quantidade) || 0;
      byProf[key].itens++;
    });
    html = `<div class="table-wrap"><table class="data-table">
      <thead><tr><th>Profissional</th><th>Registros de Saída</th><th>Total Unidades</th></tr></thead>
      <tbody>${Object.keys(byProf).length === 0 ? '<tr><td colspan="3" class="empty-row">Sem dados.</td></tr>' :
        Object.entries(byProf).sort((a, b) => b[1].total - a[1].total).map(([nome, d]) =>
          `<tr><td><strong>${nome}</strong></td><td>${d.itens} registros</td><td>${d.total} unidades</td></tr>`
        ).join('')}
      </tbody></table></div>`;
  }

  conteudo.innerHTML = html;
}

function printRelatorio() { window.print(); }

// ========== GLOBAL SEARCH ==========
document.getElementById('globalSearch').addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    const q = e.target.value.trim();
    if (!q) return;
    navigateTo('produtos');
    document.getElementById('searchProduto').value = q;
    renderProdutos();
  }
});

// ========== SEED DEMO DATA ==========
function seedDemo() {
  const makeId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 6);

  state.profissionais = [
    { id: makeId(), nome: 'Tainara Santos', especialidade: 'Esteticista', registro: '', telefone: '', email: '', status: 'Ativo' },
    { id: makeId(), nome: 'Thaís Oliveira', especialidade: 'Biomédica', registro: '', telefone: '', email: '', status: 'Ativo' },
    { id: makeId(), nome: 'Carol Ferreira', especialidade: 'Esteticista', registro: '', telefone: '', email: '', status: 'Ativo' },
    { id: makeId(), nome: 'Lyara Rodrigues', especialidade: 'Proprietária', registro: '', telefone: '', email: '', status: 'Ativo' },
  ];

  state.produtos = [
    { id: makeId(), nome: 'Algodão (Rolo 500g)', categoria: 'Materiais de Uso Geral', unidade: 'un', quantidade: 5, minimo: 5, custo: 15.90, validade: '', obs: 'Produto de exemplo' },
    { id: makeId(), nome: 'Acetona Profissional 500ml', categoria: 'Materiais de Uso Geral', unidade: 'fr', quantidade: 6, minimo: 3, custo: 22.00, validade: '', obs: 'Produto de exemplo' },
  ];

  state.entradas = [];
  state.saidas = [];
  state.fornecedores = [];

  saveLocalState();
}

function resetarSistema() {
  showConfirm("Deseja realmente limpar todos os dados do sistema e manter apenas os 2 produtos de exemplo? Todos os registros locais de produtos, entradas, saídas e fornecedores serão limpos.", () => {
    seedDemo();
    showToast("Dados locais limpos com sucesso!", "success");
    navigateTo("dashboard");
    renderDashboard();
    
    if (APPS_SCRIPT_URL) {
      setTimeout(() => {
        showConfirm("Sua conta está conectada ao Google Sheets. Deseja exportar essa limpeza para a sua planilha na nuvem agora?", () => {
          syncAllToSheets();
        });
      }, 500);
    }
  });
}

// ========== INIT ==========
async function init() {
  // 1. Carrega localStorage imediatamente (instantâneo)
  loadLocalState();

  // 2. Renderiza dashboard com dados locais
  navigateTo('dashboard');

  // 3. Tenta carregar do Google Sheets em background
  if (APPS_SCRIPT_URL) {
    showLoadingOverlay(true);
    const ok = await loadFromSheets();
    showLoadingOverlay(false);

    if (ok) {
      // Re-renderiza com dados do Sheets
      navigateTo('dashboard');
      if (state.profissionais.length === 0 && state.produtos.length === 0) {
        seedDemo();
        navigateTo('dashboard');
      }
    } else {
      showToast('Usando dados locais (Google Sheets indisponível)', 'error');
      if (state.profissionais.length === 0) seedDemo();
    }
  } else {
    // Sem URL configurada
    if (state.profissionais.length === 0) seedDemo();
    navigateTo('dashboard');

    // Mostra banner após 1s
    setTimeout(() => {
      const banner = document.getElementById('configBanner');
      if (banner) banner.style.display = 'flex';
    }, 1000);
    setSyncStatus('idle');
  }
}

// GO!
init();
